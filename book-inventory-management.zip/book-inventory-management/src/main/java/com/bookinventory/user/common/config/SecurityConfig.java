package com.bookinventory.user.common.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication
        .UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final JwtAuthFilter jwtAuthFilter;

    public SecurityConfig(JwtAuthFilter jwtAuthFilter) {
        this.jwtAuthFilter = jwtAuthFilter;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http)
            throws Exception {

        http
            // Disable CSRF — not needed for stateless REST APIs
            .csrf(csrf -> csrf.disable())

            // Stateless — no sessions, every request must carry token
            .sessionManagement(session -> session
                .sessionCreationPolicy(
                    SessionCreationPolicy.STATELESS))

            .authorizeHttpRequests(auth -> auth

                // PUBLIC
                .requestMatchers(HttpMethod.POST,
                        "/api/users/register",
                        "/api/users/login")
                        .permitAll()

                .requestMatchers(HttpMethod.GET,
                        "/api/roles",
                        "/api/roles/**")
                        .permitAll()

                // ADMIN only
                .requestMatchers(HttpMethod.GET,
                        "/api/users")
                        .hasRole("Admin")

                .requestMatchers(HttpMethod.PUT,
                        "/api/users/*/role/*")
                        .hasRole("Admin")

                .requestMatchers(HttpMethod.DELETE,
                        "/api/users/*")
                        .hasRole("Admin")

                .requestMatchers(HttpMethod.GET,
                        "/api/purchases/inventory/*")
                        .hasRole("Admin")

                // All remaining endpoints need valid token
                .anyRequest().authenticated()
            )

            // Register JWT filter before Spring's default auth filter
            .addFilterBefore(jwtAuthFilter,
                UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}