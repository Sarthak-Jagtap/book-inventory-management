package com.bookinventory.user.common.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.bookinventory.user.util.JwtUtil;

import java.io.IOException;
import java.util.Collections;

@Component
public class JwtAuthFilter extends OncePerRequestFilter {

    private final JwtUtil jwtUtil;

    public JwtAuthFilter(JwtUtil jwtUtil) {
        this.jwtUtil = jwtUtil;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {

        // Step 1: Read Authorization header from incoming request
        String authHeader = request.getHeader("Authorization");

        // Step 2: If no header or not Bearer token → skip, let it pass
        // Public endpoints like /login and /register will pass through here
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            filterChain.doFilter(request, response);
            return;
        }

        // Step 3: Remove "Bearer " prefix to get raw token
        String token = authHeader.substring(7);

        // Step 4: Check if token is valid
        if (!jwtUtil.isTokenValid(token)) {
            filterChain.doFilter(request, response);
            return;
        }

        // Step 5: Extract userName and roleName from token
        String userName = jwtUtil.extractUserName(token);
        String roleName = jwtUtil.extractRoleName(token);

        // Step 6: Build Spring Security authentication object
        // Collections.singletonList = list with exactly one role
        UsernamePasswordAuthenticationToken authentication =
                new UsernamePasswordAuthenticationToken(
                        userName,
                        null,
                        Collections.singletonList(
                            new SimpleGrantedAuthority("ROLE_" + roleName))
                );

        // Step 7: Register this authentication in Spring Security context
        // This marks the request as "authenticated"
        SecurityContextHolder.getContext()
                .setAuthentication(authentication);

        // Step 8: Move to next filter / controller
        filterChain.doFilter(request, response);
    }
}